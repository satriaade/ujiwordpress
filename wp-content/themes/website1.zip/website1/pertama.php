<!DOCTYPE html>
<html>
<head>
  <title>Belajar</title>
  <link rel="stylesheet" type="text/css" href="gaya.css">
</head>
<body>
  <div class="kepala">
  <h1>Website Saya</h1>
  <p>Silahkan resize untuk melihat perubahan.</p>
</div>

<div class="navigasiatas">
  <a href="#">Link</a>
  <a href="#">Link</a>
  <a href="#">Link</a>
  <a href="#" style="float:right">Link</a>
</div>

<div class="baris">
  <div class="kolom kiri">
    <div class="kartu">
      <h2>Judul Kepala</h2>
      <h5>Deskripsi Title, 22 September 2020</h5>
      <div class="gambarbelakang" style="height:200px;">Gambar</div>
      <p>Beberapa teks...</p>
      <p>Kota Tarakan adalah sebuah kota di Provinsi Kalimantan Utara, Indonesia dan juga merupakan kota terbesar di Kalimantan Utara. Kota ini memiliki luas wilayah 677,53 km² dan sesuai dengan data Badan Pusat Statistik 2020, kota Tarakan berpenduduk sebanyak 246.720 jiwa.</p>
    </div>
    <div class="kartu">
      <h2>Judul Kepala</h2>
      <h5>Deskripsi Title, 22 September 2020</h5>
      <div class="gambarbelakang" style="height:200px;">Gambar</div>
      <p>Beberapa teks...</p>
      <p>Kota Tarakan beriklim tropis dengan suhu udara minimum 24,1 °C dan maksimum 31,1 °C, kondisi ini membuat Kota Tarakan memiliki Kelembapan rata-rata ±84%.</p>
    </div>
  </div>
  <div class="kolomkanan">
    <div class="kartu">
      <h2>Tentang Saya</h2>
      <div class="gambarbelakang" style="height:100px;">Gambar</div>
      <p>Beberapa teks tentang saya..</p>
    </div>
    <div class="kartu">
      <h3>Postingan Favorit</h3>
      <div class="gambarbelakang"><p>Gambar</p></div>
      <div class="gambarbelakang"><p>Gambar</p></div>
      <div class="gambarbelakang"><p>Gambar</p></div>
    </div>
    <div class="kartu">
      <h3>Ikuti Saya </h3>
      <p>Beberapa teks...</p>
    </div>
  </div>
</div>

<div class="kaki">
  <h2>Kaki</h2>
  <p>Copyright @ Satria</p>
</div>

</body>
</html>